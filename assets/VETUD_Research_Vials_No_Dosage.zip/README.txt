VETUD — RESEARCH VIAL COLLECTION
Quantity-free label edition

Contents
• 01_Main_24: 24 named product PNGs.
• 02_Additional_4: Ipamorelin, DSIP, ARA-290 and Selank.
• Preview.html: offline visual gallery. Extract the full ZIP, then open it in a browser.
• Product_Index.csv: filenames, source listings and source URLs.
• catalog.json: structured product index.

Design
Photorealistic clear laboratory vials on white backgrounds, cobalt caps, the VETUD molecular logo, alpine contour illustrations and blue gradient waves.
Labels retain product identifiers, RESEARCH USE ONLY and vetud.com.
All dosage and volume amounts are omitted. Numbers that are part of product names remain.
The phrase NOT FOR HUMAN USE is omitted.
No purity percentages, testing certifications or lot identifiers were invented.

These are packaging concept renders, not production label dielines.
The PNGs are original native-resolution generated files, with no enlarging or recompression.

Catalog mapping
The source shop contained 28 listings when inspected. The first 24 are grouped as the main collection; the other four are included separately.
TZ-2 corresponds to the source listing HEEZ-2 TZ.
SM-1 corresponds to the source listing HEEZ-1 SM.
Those source pages use coded names; their underlying compound identities were not established.
H2O corresponds to HEEZ H2O. The source does not specify its formulation.

Source: https://heezresearch.com/shop/

